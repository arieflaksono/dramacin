import { Drama } from '../types';
import { MOCK_DRAMAS } from '../constants';

const API_BASE = 'https://api.sansekai.my.id/dramabox';

// Helper to normalize different API response structures
const normalizeDrama = (item: any, additionalProps: Partial<Drama> = {}): Drama => {
  // Helper to resolve image URL
  const resolveImage = (path: string | undefined, type: 'poster' | 'backdrop') => {
    if (!path) return type === 'poster' ? 'https://picsum.photos/300/450' : 'https://picsum.photos/1920/1080';
    if (path.startsWith('http')) return path;
    // Assume relative paths starting with / are from TMDB
    if (path.startsWith('/')) {
        return `https://image.tmdb.org/t/p/${type === 'poster' ? 'w500' : 'original'}${path}`;
    }
    return path;
  };

  const poster = item.poster_path || item.thumbnail || item.poster || item.image || item.cover;
  const backdrop = item.backdrop_path || item.cover_url || item.banner || item.backdrop || poster; // Fallback to poster if no backdrop

  const baseGenres = Array.isArray(item.genres) 
    ? item.genres.map((g: any) => typeof g === 'string' ? g : g.name) 
    : (item.genre ? (Array.isArray(item.genre) ? item.genre : [item.genre]) : ['Drama']);

  const extraGenres = additionalProps.genre || [];
  const mergedGenres = Array.from(new Set([...baseGenres, ...extraGenres])) as string[];

  // Separate genre from other additional props to avoid type conflict with spread
  const { genre: _unusedGenre, ...otherProps } = additionalProps;

  return {
    id: String(item.id || Math.random().toString(36).substr(2, 9)),
    title: item.title || item.name || item.drama_name || 'Untitled Drama',
    description: item.overview || item.description || item.synopsis || item.summary || 'No description available.',
    thumbnailUrl: resolveImage(poster, 'poster'),
    coverUrl: resolveImage(backdrop, 'backdrop'),
    rating: Number(item.rating || item.vote_average || item.score || 4.5),
    year: new Date(item.release_date || item.first_air_date || item.created_at || Date.now()).getFullYear(),
    episodes: Number(item.episodes || item.number_of_episodes || item.episode_count || item.total_episodes || 12),
    isVertical: Boolean(item.is_vertical || item.type === 'vertical' || item.category === 'Short Drama' || (poster && !backdrop)),
    trending: Boolean(item.popularity > 50 || item.trending || item.is_trending),
    ...otherProps,
    genre: mergedGenres,
  };
};

const fetchEndpoint = async (endpoint: string): Promise<any[]> => {
    try {
        console.log(`[API] Fetching: ${API_BASE}${endpoint}`);
        const response = await fetch(`${API_BASE}${endpoint}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            }
        });
        
        if (!response.ok) {
            console.warn(`[API] Error fetching ${endpoint}: ${response.status} ${response.statusText}`);
            return [];
        }
        
        const json = await response.json();
        
        // Handle various response wrappers
        if (Array.isArray(json)) return json;
        if (json.data && Array.isArray(json.data)) return json.data;
        if (json.results && Array.isArray(json.results)) return json.results;
        
        return [];
    } catch (e) {
        console.warn(`[API] Network error fetching ${endpoint}:`, e);
        return [];
    }
};

export const fetchDramas = async (): Promise<Drama[]> => {
  try {
    console.log('Connecting to Sansekai API...');
    
    // Fetch in parallel
    const [trendingRaw, latestRaw, forYouRaw, dubIndoRaw, vipRaw] = await Promise.all([
        fetchEndpoint('/trending'),
        fetchEndpoint('/latest'),
        fetchEndpoint('/foryou'),
        fetchEndpoint('/dubindo'),
        fetchEndpoint('/vip')
    ]);

    const allDramas = new Map<string, Drama>();

    // Process Trending
    trendingRaw.forEach(item => {
        const drama = normalizeDrama(item, { trending: true });
        allDramas.set(drama.id, drama);
    });

    // Process Latest
    latestRaw.forEach(item => {
        const existing = allDramas.get(String(item.id));
        if (existing) {
            existing.isNew = true;
        } else {
            allDramas.set(String(item.id), normalizeDrama(item, { isNew: true }));
        }
    });

    // Process For You
    forYouRaw.forEach(item => {
        if (!allDramas.has(String(item.id))) {
            allDramas.set(String(item.id), normalizeDrama(item));
        }
    });

    // Process Dub Indo
    dubIndoRaw.forEach(item => {
        const id = String(item.id);
        const existing = allDramas.get(id);
        if (existing) {
            if (!existing.genre.includes('Dub Indo')) existing.genre.push('Dub Indo');
        } else {
            allDramas.set(id, normalizeDrama(item, { genre: ['Dub Indo'] }));
        }
    });

    // Process VIP
    vipRaw.forEach(item => {
        const id = String(item.id);
        const existing = allDramas.get(id);
        if (existing) {
            existing.isVip = true;
        } else {
            allDramas.set(id, normalizeDrama(item, { isVip: true }));
        }
    });

    const results = Array.from(allDramas.values());

    if (results.length === 0) {
        console.warn('No data found from APIs, using fallback mock data.');
        return MOCK_DRAMAS;
    }

    console.log(`[API] Successfully loaded ${results.length} dramas.`);
    return results;

  } catch (error) {
    console.error('Critical failure in drama service:', error);
    return MOCK_DRAMAS;
  }
};

export const searchDramas = async (query: string): Promise<Drama[]> => {
    try {
        const raw = await fetchEndpoint(`/search?keyword=${encodeURIComponent(query)}`);
        if (raw && raw.length > 0) {
            return raw.map(item => normalizeDrama(item));
        }
    } catch (e) {
        console.warn('API Search failed, falling back to local filter');
    }

    // Fallback: search in MOCK_DRAMAS if API returns nothing or fails
    const lowerQuery = query.toLowerCase();
    return MOCK_DRAMAS.filter(d => 
        d.title.toLowerCase().includes(lowerQuery) || 
        d.description.toLowerCase().includes(lowerQuery) ||
        d.genre.some(g => g.toLowerCase().includes(lowerQuery))
    );
};

export const getPopularSearches = async (): Promise<string[]> => {
    const raw = await fetchEndpoint('/populersearch');
    // Assuming raw is array of strings or objects
    return raw.map((item: any) => typeof item === 'string' ? item : item.keyword || item.title);
};

export const getDramaDetail = async (id: string): Promise<Drama | null> => {
    const raw = await fetchEndpoint(`/detail?id=${id}`);
    if (!raw || (Array.isArray(raw) && raw.length === 0)) return null;
    return normalizeDrama(Array.isArray(raw) ? raw[0] : raw);
};

export const getDramaEpisodes = async (id: string): Promise<any[]> => {
    const raw = await fetchEndpoint(`/allepisode?id=${id}`);
    return raw;
};

export const getRandomDrama = async (): Promise<Drama | null> => {
    const raw = await fetchEndpoint('/randomdrama');
    if (!raw || (Array.isArray(raw) && raw.length === 0)) return null;
    return normalizeDrama(Array.isArray(raw) ? raw[0] : raw);
};