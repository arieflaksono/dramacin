import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateDramaRecommendation = async (
  history: Message[],
  currentQuery: string
): Promise<string> => {
  try {
    // Construct a chat-like prompt history
    const conversation = history.map(msg => 
      `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.text}`
    ).join('\n');

    const prompt = `
      You are DramaBot, an enthusiastic and knowledgeable AI assistant for a drama streaming app called 'DramaBox'.
      
      Your goal is to recommend dramas based on the user's mood or request.
      We have a catalog that includes genres like Romance, CEO/Rich Family, Historical, Thriller, Revenge, Sci-Fi, and Fantasy.
      Some popular titles in our mock catalog are: "The CEO's Secret Vow", "Reborn for Revenge", "Shadows of the Palace", "Cyber Heart".
      
      Conversation History:
      ${conversation}
      
      User: ${currentQuery}
      
      Provide a short, engaging response recommending a type of drama or specific title from our catalog. Keep it under 50 words. Be emojis friendly! 🍿
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "I couldn't think of a recommendation right now. Try searching for 'Romance'!";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I'm having trouble connecting to the server. Please try again later.";
  }
};