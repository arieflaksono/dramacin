import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight, PlayCircle, PlusCircle } from 'lucide-react';
import { Drama } from '../types';

interface ContentRowProps {
  title: string;
  dramas: Drama[];
  onDramaSelect: (drama: Drama) => void;
}

export const ContentRow: React.FC<ContentRowProps> = ({ title, dramas, onDramaSelect }) => {
  const rowRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
      rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-4 my-8 group relative px-4 md:px-12">
      <h2 className="text-xl md:text-2xl font-bold text-gray-100 hover:text-white cursor-pointer transition-colors inline-block">
        {title}
      </h2>
      
      <div className="relative">
        <button 
          onClick={() => scroll('left')}
          className="absolute left-0 top-0 bottom-0 z-40 bg-black/50 hover:bg-black/70 p-2 hidden group-hover:flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 h-full w-12 rounded-r"
        >
          <ChevronLeft className="h-8 w-8 text-white" />
        </button>

        <div 
          ref={rowRef}
          className="flex space-x-4 overflow-x-auto hide-scrollbar scroll-smooth pb-4 px-1"
        >
          {dramas.map((drama) => (
            <div 
              key={drama.id}
              onClick={() => onDramaSelect(drama)}
              className={`relative flex-none cursor-pointer transition-all duration-300 hover:scale-105 hover:z-10 group/card ${drama.isVertical ? 'w-[160px] md:w-[200px]' : 'w-[240px] md:w-[300px]'}`}
            >
              <div className={`relative overflow-hidden rounded-md shadow-lg bg-dark-800 ${drama.isVertical ? 'aspect-[2/3]' : 'aspect-video'}`}>
                <img 
                  src={drama.thumbnailUrl} 
                  alt={drama.title}
                  className="w-full h-full object-cover transition-opacity duration-300"
                />
                
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                  <div className="flex items-center space-x-3 mb-2">
                    <button className="bg-white rounded-full p-2 hover:bg-gray-200 transition-colors">
                       <PlayCircle className="h-6 w-6 text-black fill-black" />
                    </button>
                    <button className="border-2 border-gray-400 rounded-full p-1.5 hover:border-white transition-colors">
                       <PlusCircle className="h-6 w-6 text-gray-300" />
                    </button>
                  </div>
                  <h3 className="font-bold text-sm md:text-base text-white">{drama.title}</h3>
                  <div className="flex items-center space-x-2 text-xs text-green-400 mt-1">
                    <span>{drama.rating} Match</span>
                    <span className="text-gray-300">{drama.episodes} eps</span>
                  </div>
                  <div className="flex gap-1 mt-2 flex-wrap">
                      {drama.genre.slice(0, 2).map(g => (
                          <span key={g} className="text-[10px] bg-gray-700 px-1.5 py-0.5 rounded text-gray-200">{g}</span>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={() => scroll('right')}
          className="absolute right-0 top-0 bottom-0 z-40 bg-black/50 hover:bg-black/70 p-2 hidden group-hover:flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 h-full w-12 rounded-l"
        >
          <ChevronRight className="h-8 w-8 text-white" />
        </button>
      </div>
    </div>
  );
};