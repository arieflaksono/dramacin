import React from 'react';
import { Play, Info, Plus } from 'lucide-react';
import { Drama } from '../types';

interface HeroProps {
  drama: Drama;
  onPlay: () => void;
}

export const Hero: React.FC<HeroProps> = ({ drama, onPlay }) => {
  return (
    <div className="relative h-[80vh] w-full overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-[10s] hover:scale-105"
        style={{ backgroundImage: `url(${drama.coverUrl})` }}
      >
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/40 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-dark-900 via-dark-900/30 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-end pb-24 md:pb-32">
        <div className="max-w-2xl space-y-4 animate-fade-in-up">
          <div className="flex items-center space-x-2 mb-2">
            <span className="bg-brand-600 text-white text-xs font-bold px-2 py-0.5 rounded">TOP 1</span>
            <span className="text-gray-300 text-sm font-medium">Trending Today</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold text-white leading-tight tracking-tight drop-shadow-lg">
            {drama.title}
          </h1>
          
          <div className="flex items-center space-x-4 text-sm text-gray-300">
            <span className="text-green-400 font-semibold">{drama.rating} Match</span>
            <span>{drama.year}</span>
            <span>{drama.episodes} Episodes</span>
            <span className="border border-gray-500 px-1 rounded text-xs">HD</span>
          </div>

          <p className="text-lg text-gray-200 line-clamp-3 md:line-clamp-none drop-shadow-md max-w-xl">
            {drama.description}
          </p>

          <div className="flex items-center space-x-4 pt-4">
            <button 
              onClick={onPlay}
              className="flex items-center bg-white text-black px-6 py-3 rounded hover:bg-gray-200 transition-colors font-bold text-lg"
            >
              <Play className="h-6 w-6 mr-2 fill-black" />
              Play
            </button>
            <button className="flex items-center bg-gray-500/40 backdrop-blur-sm text-white px-6 py-3 rounded hover:bg-gray-500/60 transition-colors font-semibold text-lg">
              <Info className="h-6 w-6 mr-2" />
              More Info
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};