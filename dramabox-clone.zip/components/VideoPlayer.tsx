import React from 'react';
import { X, Play, Pause, Volume2, SkipForward, Maximize } from 'lucide-react';

interface VideoPlayerProps {
  onClose: () => void;
  title: string;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ onClose, title }) => {
  const [isPlaying, setIsPlaying] = React.useState(true);

  return (
    <div className="fixed inset-0 z-[60] bg-black flex flex-col">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center bg-gradient-to-b from-black/80 to-transparent z-10">
        <h2 className="text-xl font-bold text-white">{title}</h2>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
          <X className="h-8 w-8 text-white" />
        </button>
      </div>

      {/* Video Area (Simulated) */}
      <div className="flex-1 flex items-center justify-center bg-gray-900 relative group cursor-pointer" onClick={() => setIsPlaying(!isPlaying)}>
         {/* Placeholder for real video */}
         <img 
            src="https://picsum.photos/1920/1080?blur=2" 
            className="absolute inset-0 w-full h-full object-cover opacity-50"
            alt="Video Background"
         />
         
         <div className="z-0 absolute text-center">
            <p className="text-gray-400 text-lg animate-pulse">Streaming from CDN...</p>
         </div>

         {!isPlaying && (
             <div className="absolute z-10 bg-black/50 p-6 rounded-full">
                 <Play className="h-12 w-12 text-white fill-white" />
             </div>
         )}
      </div>

      {/* Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/90 via-black/60 to-transparent">
        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-gray-600 rounded-full mb-4 cursor-pointer hover:h-2 transition-all">
          <div className="w-1/3 h-full bg-brand-600 rounded-full relative">
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 bg-brand-600 rounded-full shadow-lg scale-0 hover:scale-100 transition-transform"></div>
          </div>
        </div>

        <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
                <button onClick={(e) => { e.stopPropagation(); setIsPlaying(!isPlaying); }}>
                    {isPlaying ? <Pause className="h-8 w-8 text-white fill-white" /> : <Play className="h-8 w-8 text-white fill-white" />}
                </button>
                <button>
                    <SkipForward className="h-8 w-8 text-white hover:text-gray-300 transition-colors" />
                </button>
                <div className="flex items-center space-x-2 group">
                    <Volume2 className="h-6 w-6 text-white" />
                    <div className="w-0 overflow-hidden group-hover:w-24 transition-all duration-300">
                        <div className="w-20 h-1 bg-white rounded ml-2"></div>
                    </div>
                </div>
                <span className="text-sm font-medium text-gray-300">12:30 / 45:00</span>
            </div>
            
            <div className="flex items-center space-x-4">
                 <span className="font-bold text-gray-300">Ep. 1</span>
                 <button>
                     <Maximize className="h-6 w-6 text-white" />
                 </button>
            </div>
        </div>
      </div>
    </div>
  );
};