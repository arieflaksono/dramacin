import React, { useState, useEffect } from 'react';
import { Search, Bell, User, Menu, X } from 'lucide-react';

interface NavbarProps {
  onSearch: (query: string) => void;
  onHome: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onSearch, onHome }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  const toggleSearch = () => {
      setShowSearch(!showSearch);
      if (showSearch) {
          setSearchQuery('');
          onHome();
      }
  };

  return (
    <nav className={`fixed w-full z-50 transition-colors duration-300 ${isScrolled ? 'bg-dark-900/95 backdrop-blur-sm shadow-lg' : 'bg-gradient-to-b from-black/80 to-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Desktop Menu */}
          <div className="flex items-center">
            <div className="flex-shrink-0 cursor-pointer" onClick={onHome}>
              <span className="text-brand-500 font-bold text-2xl tracking-tighter">DRAMABOX</span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <button onClick={onHome} className="text-white hover:text-brand-500 px-3 py-2 rounded-md text-sm font-medium transition-colors">Home</button>
                <a href="#" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium transition-colors">Series</a>
                <a href="#" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium transition-colors">Movies</a>
                <a href="#" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium transition-colors">My List</a>
              </div>
            </div>
          </div>

          {/* Right Icons */}
          <div className="hidden md:flex items-center space-x-6">
            <div className={`flex items-center transition-all duration-300 ${showSearch ? 'w-64' : 'w-auto'}`}>
                {showSearch ? (
                    <form onSubmit={handleSearchSubmit} className="flex items-center w-full bg-black/50 border border-gray-600 rounded px-2 py-1">
                        <Search className="h-4 w-4 text-gray-400 mr-2" />
                        <input 
                            type="text" 
                            autoFocus
                            className="bg-transparent border-none focus:outline-none text-white text-sm w-full placeholder-gray-400"
                            placeholder="Titles, people, genres"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            onBlur={() => { if(!searchQuery) setShowSearch(false); }}
                        />
                        <button type="button" onClick={toggleSearch}>
                             <X className="h-4 w-4 text-gray-400 hover:text-white" />
                        </button>
                    </form>
                ) : (
                    <button onClick={() => setShowSearch(true)} className="text-gray-300 hover:text-white transition-colors">
                        <Search className="h-5 w-5" />
                    </button>
                )}
            </div>

            <button className="text-gray-300 hover:text-white transition-colors">
              <Bell className="h-5 w-5" />
            </button>
            <div className="flex items-center space-x-2 cursor-pointer group">
              <div className="h-8 w-8 rounded bg-brand-600 flex items-center justify-center text-white font-bold">
                <User className="h-5 w-5" />
              </div>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center gap-4">
             <button onClick={() => setShowSearch(!showSearch)} className="text-gray-300 hover:text-white">
                <Search className="h-5 w-5" />
             </button>
             <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-gray-300 hover:text-white">
               {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
             </button>
          </div>
        </div>
        
        {/* Mobile Search Bar */}
        {showSearch && (
             <div className="md:hidden px-2 pb-3">
                <form onSubmit={handleSearchSubmit} className="flex items-center w-full bg-dark-800 border border-dark-600 rounded px-3 py-2">
                     <input 
                        type="text" 
                        autoFocus
                        className="bg-transparent border-none focus:outline-none text-white w-full placeholder-gray-500"
                        placeholder="Search..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                     <button type="submit" className="ml-2 text-brand-500 font-medium">GO</button>
                </form>
             </div>
        )}
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-dark-900 border-t border-dark-700">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <button onClick={onHome} className="text-white block px-3 py-2 rounded-md text-base font-medium w-full text-left">Home</button>
            <a href="#" className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Series</a>
            <a href="#" className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Movies</a>
            <a href="#" className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">My List</a>
          </div>
        </div>
      )}
    </nav>
  );
};